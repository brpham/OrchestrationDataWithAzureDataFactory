# sample python script
print('Hello, world!')